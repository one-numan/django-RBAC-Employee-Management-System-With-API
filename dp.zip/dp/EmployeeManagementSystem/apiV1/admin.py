from django.contrib import admin
from .models import Employee2, Role2
# Register your models here.

admin.site.register(Employee2)
admin.site.register(Role2)
